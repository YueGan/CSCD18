Notes:

 * Don't forget to complete the autotester_id.txt
 * If you have done any crunchy work, put your rendered images (in .jpg format, good resolution)
   along with a text file describing your crunchy features in a .zip file called 'crunchy.zip'
   and submit that along with the remaning requested files and/or renders.

 
